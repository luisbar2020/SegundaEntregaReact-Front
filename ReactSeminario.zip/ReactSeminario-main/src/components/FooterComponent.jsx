import React from 'react';
import '../assets/styles/componentsStyles/FooterComponent.css';

const FooterComponent = () => {
  return (
    <footer className="footer">
      <div className="container">
        <p> Integrantes:</p>
      </div>
    </footer>
  );
};

export default FooterComponent;
